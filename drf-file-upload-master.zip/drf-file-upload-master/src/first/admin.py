from django.contrib import admin
from .models import FileModel, ImageModel

admin.site.register(FileModel)
admin.site.register(ImageModel)
